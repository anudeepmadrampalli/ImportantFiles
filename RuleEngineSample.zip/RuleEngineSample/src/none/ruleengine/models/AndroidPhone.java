package none.ruleengine.models;

import none.ruleengine.specification.IRuleEngine;

public class AndroidPhone implements IRuleEngine<Phone, Phone>{

	@Override
	public boolean matches(final Phone input) {
		return input.getType().equals(Phone.OSType.Android);
	}

	@Override
	public Phone process(final Phone input) {
		input.setMake("Google");
		input.setType(Phone.OSType.Android);
		return input;
	}

}
