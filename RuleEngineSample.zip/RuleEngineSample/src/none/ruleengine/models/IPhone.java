package none.ruleengine.models;

import none.ruleengine.specification.IRuleEngine;

public class IPhone implements IRuleEngine<Phone, Phone>{

	@Override
	public boolean matches(final Phone input) {
		return input.getType().equals(Phone.OSType.IPhone);
	}

	@Override
	public Phone process(final Phone input) {
		input.setMake("Apple");
		input.setType(Phone.OSType.IPhone);
		return input;
	}



}
