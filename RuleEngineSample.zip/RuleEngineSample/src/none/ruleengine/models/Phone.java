package none.ruleengine.models;

public class Phone {

	public enum OSType{
		Android, IPhone, Windows
	};

	private String make;

	private OSType type;

	public Phone(final String make, final OSType type) {
		super();
		this.make = make;
		this.type = type;
	}

	public String getMake() {
		return make;
	}

	public OSType getType() {
		return type;
	}

	public void setMake(final String make) {
		this.make = make;
	}

	public void setType(final OSType type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Phone [make=" + make + ", type=" + type + "]";
	}

}
