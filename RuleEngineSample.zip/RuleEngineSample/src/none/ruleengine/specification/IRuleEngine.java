package none.ruleengine.specification;

public interface IRuleEngine<I, O> {

	boolean matches(I input);

	O process(I input);


}
