package none.ruleengine.implementation;

import java.util.ArrayList;
import java.util.List;

import none.ruleengine.models.Phone;
import none.ruleengine.specification.IRuleEngine;

public class RuleEngineImpl {

	List<IRuleEngine<Phone, Phone>> rules;

	public RuleEngineImpl() {
		rules = new ArrayList<>();
	}

	public RuleEngineImpl register(final IRuleEngine<Phone, Phone> rule) {
		rules.add(rule);
		return this;

	}

	public Phone rule(final Phone phone) {
		return rules.stream().filter(rule -> rule.matches(phone)).map(rule -> rule.process(phone)).findFirst()
				.orElseThrow(() -> new RuntimeException("No match found"));
	}

}
