package none.ruleengine.testclass;

import none.ruleengine.implementation.RuleEngineImpl;
import none.ruleengine.models.AndroidPhone;
import none.ruleengine.models.IPhone;
import none.ruleengine.models.Phone;

public class TestRuleEngineImpl {

	public static void main(final String[] args) {


		final RuleEngineImpl ruleEngine = new RuleEngineImpl();
		ruleEngine.register(new IPhone());
		ruleEngine.register(new AndroidPhone());

		final Phone androidPhone = new Phone("Google", Phone.OSType.Android);
		final Phone iPhone = new Phone("Apple", Phone.OSType.IPhone);
		final Phone dummyPhone = new Phone("Chineese", Phone.OSType.Windows);

		final Phone validAndroid = ruleEngine.rule(androidPhone);
		final Phone validIPhone = ruleEngine.rule(iPhone);

		System.out.println(validAndroid);
		System.out.println(validIPhone);
		System.out.println(ruleEngine.rule(dummyPhone));


	}

}
