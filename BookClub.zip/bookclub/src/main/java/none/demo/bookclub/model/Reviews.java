package none.demo.bookclub.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Reviews")
public class Reviews implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String content;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private LocalDate publishedDate;

	private float rating;

	private String reviewerName;

	public String getContent() {
		return content;
	}

	public Long getId() {
		return id;
	}

	public LocalDate getPublishedDate() {
		return publishedDate;
	}

	public float getRating() {
		return rating;
	}

	public String getReviewerName() {
		return reviewerName;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setPublishedDate(LocalDate publishedDate) {
		this.publishedDate = publishedDate;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public void setReviewerName(String reviewerName) {
		this.reviewerName = reviewerName;
	}

	@Override
	public String toString() {
		return "Review [reviewerName=" + reviewerName + ", content=" + content + ", rating=" + rating
				+ ", publishedDate=" + publishedDate + "]";
	}


}
