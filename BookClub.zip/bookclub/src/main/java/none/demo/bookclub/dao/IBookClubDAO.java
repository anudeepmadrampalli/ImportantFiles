package none.demo.bookclub.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import none.demo.bookclub.model.Book;

@Repository
public interface IBookClubDAO extends JpaRepository<Book, Long>{

	 @Query(value = "select * from books b where b.title = ?1", nativeQuery = true)
	  List<Book> findByTitle(String title);

}
