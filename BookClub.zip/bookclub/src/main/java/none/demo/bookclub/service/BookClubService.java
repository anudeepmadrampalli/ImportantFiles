package none.demo.bookclub.service;

public class BookClubService {

}
