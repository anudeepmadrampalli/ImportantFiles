package none.demo.bookclub.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Books", uniqueConstraints = @UniqueConstraint(name = "uq_books", columnNames = {"title", "author", "isbn"}))
@JsonIgnoreProperties(value = { "createdAt", "updatedAt" }, allowGetters = true)
public class Book implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@NotBlank
	private String author;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private Long isbn;

	private LocalDate publishedDate;

    @OneToMany( targetEntity=Reviews.class, cascade = {CascadeType.ALL} )
	private List<Reviews> reviews;

	@NotBlank
	private String title;


	public String getAuthor() {
		return author;
	}


	public Long getId() {
		return id;
	}

	public Long getIsbn() {
		return isbn;
	}

	public LocalDate getPublishedDate() {
		return publishedDate;
	}

	public List<Reviews> getReviews() {
		return reviews;
	}

	public String getTitle() {
		return title;
	}


	public void setAuthor(String author) {
		this.author = author;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setIsbn(Long isbn) {
		this.isbn = isbn;
	}

	public void setPublishedDate(LocalDate publishedDate) {
		this.publishedDate = publishedDate;
	}

	public void setReview(List<Reviews> reviews) {
		this.reviews = reviews;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public String toString() {
		return "Book [title=" + title + ", author=" + author + ", publishedDate=" + publishedDate + ", isbn=" + isbn
				+ ", reviews=" + reviews + "]";
	}

}
